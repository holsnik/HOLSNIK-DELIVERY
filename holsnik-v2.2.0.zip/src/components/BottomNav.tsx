import { cn } from '../utils/cn';
import type { TabName } from '../types';
import { Home, ShoppingBag, Package, Camera, User, Shield } from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useNotificationStore } from '../store/notificationStore';

const BASE_TABS: { key: TabName; label: string; Icon: typeof Home }[] = [
  { key: 'home', label: 'Главная', Icon: Home },
  { key: 'order', label: 'Заказ', Icon: ShoppingBag },
  { key: 'tracking', label: 'Посылки', Icon: Package },
  { key: 'photos', label: 'Фото', Icon: Camera },
  { key: 'profile', label: 'Профиль', Icon: User },
];

export function BottomNav({ activeTab, onTabChange }: { activeTab: TabName; onTabChange: (t: TabName) => void }) {
  const isAdmin = useAuthStore((s) => s.user?.isAdmin === true);
  const unreadCount = useNotificationStore((s) => s.getUnreadCount());

  const tabs = isAdmin
    ? [...BASE_TABS, { key: 'admin' as TabName, label: 'Админ', Icon: Shield }]
    : BASE_TABS;

  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 nav-glass bg-surface/80 border-t border-stroke-soft safe-bottom">
      <div className="flex items-center justify-around h-14 max-w-lg mx-auto">
        {tabs.map(({ key, label, Icon }) => {
          const active = activeTab === key;
          const isProfileTab = key === 'profile';
          return (
            <button key={key} onClick={() => onTabChange(key)}
              className={cn('flex flex-col items-center justify-center gap-0.5 flex-1 h-full transition-colors relative', active ? 'text-primary' : 'text-text-t')}>
              <div className="relative">
                <Icon size={active ? 21 : 19} strokeWidth={active ? 2.2 : 1.5} />
                {isProfileTab && unreadCount > 0 && (
                  <span className="absolute -top-1.5 -right-2 w-4 h-4 bg-error text-white text-[8px] font-bold rounded-full flex items-center justify-center">
                    {unreadCount > 9 ? '9+' : unreadCount}
                  </span>
                )}
              </div>
              <span className={cn('text-[10px] font-medium', active && 'font-semibold')}>{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
