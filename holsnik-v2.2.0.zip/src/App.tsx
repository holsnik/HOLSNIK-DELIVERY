import { useState, useEffect } from 'react';
import { useAuthStore } from './store/authStore';
import { useTelegram } from './hooks/useTelegram';
import { useNotificationStore } from './store/notificationStore';
import { AuthPage } from './pages/AuthPage';
import { HomePage } from './pages/HomePage';
import { OrderPage } from './pages/OrderPage';
import { TrackingPage } from './pages/TrackingPage';
import { PhotosPage } from './pages/PhotosPage';
import { ProfilePage } from './pages/ProfilePage';
import { AdminPage } from './pages/AdminPage';
import { BottomNav } from './components/BottomNav';
import { FloatingAIButton } from './components/FloatingAIButton';
import { ChatWindow } from './components/ChatWindow';
import type { TabName } from './types';

export default function App() {
  const isAuthenticated = useAuthStore((s) => s.isAuthenticated);
  const loginWithTelegram = useAuthStore((s) => s.loginWithTelegram);
  const logout = useAuthStore((s) => s.logout);
  const user = useAuthStore((s) => s.user);
  const [activeTab, setActiveTab] = useState<TabName>('home');
  const { isTelegram, user: tgUser } = useTelegram();

  // Авто-вход через Telegram
  useEffect(() => {
    if (isTelegram && tgUser && !isAuthenticated) {
      loginWithTelegram(tgUser);
    }
  }, [isTelegram, tgUser, isAuthenticated, loginWithTelegram]);

  if (!isAuthenticated) {
    return <AuthPage />;
  }

  const handleLogout = () => {
    logout();
    setActiveTab('home');
  };

  const renderPage = () => {
    switch (activeTab) {
      case 'home':
        return <HomePage onNavigate={(tab) => setActiveTab(tab)} />;
      case 'order':
        return <OrderPage />;
      case 'tracking':
        return <TrackingPage />;
      case 'photos':
        return <PhotosPage />;
      case 'profile':
        return (
          <ProfilePage
            onNavigateTracking={() => setActiveTab('tracking')}
            onLogout={handleLogout}
            onNavigateAdmin={() => setActiveTab('admin')}
          />
        );
      case 'admin':
        return <AdminPage onBack={() => setActiveTab('profile')} />;
      default:
        return <HomePage onNavigate={(tab) => setActiveTab(tab)} />;
    }
  };

  return (
    <div className="h-full flex flex-col bg-bg max-w-lg mx-auto relative">
      <div className="flex-1 overflow-y-auto overflow-x-hidden pb-20">
        {renderPage()}
      </div>
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
      <FloatingAIButton />
      <ChatWindow />
    </div>
  );
}
