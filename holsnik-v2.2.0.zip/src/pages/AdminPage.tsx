import { useState } from 'react';
import { KCard } from '../components/ui/KCard';
import { KButton } from '../components/ui/KButton';
import { KInput, KTextarea } from '../components/ui/KInput';
import { useOrderStore } from '../store/orderStore';
import { useAuthStore } from '../store/authStore';
import { useNotificationStore } from '../store/notificationStore';
import { notifyUser, notifyUsersBulk } from '../lib/telegram';
import { StatusBadge, StatusProgress } from '../components/ui/StatusBadge';
import { formatByn, formatWeight, formatDate, getDeliveryMethodName } from '../lib/helpers';
import type { Order, OrderStatus } from '../types';
import { ArrowLeft, Send, Package, Users, Bell, Search, ChevronDown, ChevronUp, RefreshCw, Check, MessageCircle } from 'lucide-react';

interface AdminPageProps {
  onBack: () => void;
}

export function AdminPage({ onBack }: AdminPageProps) {
  const orders = useOrderStore((s) => s.orders);
  const updateOrderStatus = useOrderStore((s) => s.updateOrderStatus);
  const user = useAuthStore((s) => s.user);
  const addNotification = useNotificationStore((s) => s.addNotification);

  const [activeSection, setActiveSection] = useState<'orders' | 'notifications' | 'stats'>('orders');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<OrderStatus | 'all'>('all');

  // Notification form state
  const [notifTitle, setNotifTitle] = useState('');
  const [notifMessage, setNotifMessage] = useState('');
  const [notifTarget, setNotifTarget] = useState<'all' | 'specific'>('all');
  const [targetUserId, setTargetUserId] = useState('');
  const [targetChatId, setTargetChatId] = useState('');
  const [sendToTelegram, setSendToTelegram] = useState(false);
  const [sendingNotif, setSendingNotif] = useState(false);
  const [notifSent, setNotifSent] = useState(false);
  const [notifResult, setNotifResult] = useState<string>('');

  const isAdmin = user?.isAdmin === true;

  if (!isAdmin) {
    return (
      <div className="page-transition px-4 py-8 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-20 h-20 bg-error/10 rounded-full flex items-center justify-center mb-4">
          <span className="text-3xl">🔒</span>
        </div>
        <h2 className="text-xl font-bold text-text mb-2">Доступ запрещён</h2>
        <p className="text-text-secondary text-center text-sm mb-6">
          У вас нет прав администратора
        </p>
        <KButton onClick={onBack} icon={<ArrowLeft size={18} />}>Назад</KButton>
      </div>
    );
  }

  const filteredOrders = orders.filter(o => {
    const q = searchQuery.toLowerCase();
    const matchSearch = !q || o.id.toLowerCase().includes(q) || o.items.some(i => i.name.toLowerCase().includes(q));
    const matchFilter = statusFilter === 'all' || o.status === statusFilter;
    return matchSearch && matchFilter;
  });

  const statusCounts = orders.reduce((acc, o) => {
    acc[o.status] = (acc[o.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const totalRevenue = orders.reduce((sum, o) => sum + o.totalPriceByn, 0);

  const handleStatusChange = (orderId: string, newStatus: OrderStatus) => {
    updateOrderStatus(orderId, newStatus);
    const order = orders.find(o => o.id === orderId);
    if (order) {
      addNotification({
        userId: order.userId,
        title: 'Статус заказа изменён',
        message: `Заказ ${orderId} теперь имеет статус: ${getStatusLabel(newStatus)}`,
        type: 'order',
        orderId: orderId,
      });
    }
  };

  const handleSendNotification = async () => {
    if (!notifTitle.trim() || !notifMessage.trim()) return;
    setSendingNotif(true);
    setNotifResult('');

    let tgResult = { success: 0, failed: 0, errors: [] as string[] };

    // Send to Telegram if enabled
    if (sendToTelegram) {
      if (notifTarget === 'all') {
        // Get unique telegram chat IDs from orders
        const chatIds = [...new Set(orders.map(o => o.telegramChatId).filter(Boolean))] as number[];
        if (chatIds.length > 0) {
          tgResult = await notifyUsersBulk({
            chatIds,
            title: notifTitle,
            message: notifMessage,
          });
        }
      } else if (targetChatId) {
        const chatIdNum = parseInt(targetChatId);
        if (!isNaN(chatIdNum)) {
          const ok = await notifyUser({
            chatId: chatIdNum,
            title: notifTitle,
            message: notifMessage,
          });
          tgResult = { success: ok ? 1 : 0, failed: ok ? 0 : 1, errors: ok ? [] : ['Failed to send'] };
        }
      }
    }

    // Add to local notifications
    if (notifTarget === 'all') {
      const userIds = [...new Set(orders.map(o => o.userId))];
      userIds.forEach(uid => {
        addNotification({
          userId: uid,
          title: notifTitle,
          message: notifMessage,
          type: 'system',
          sentToTelegram: sendToTelegram && tgResult.success > 0,
        });
      });
    } else {
      addNotification({
        userId: targetUserId || 'user',
        title: notifTitle,
        message: notifMessage,
        type: 'system',
        sentToTelegram: sendToTelegram && tgResult.success > 0,
      });
    }

    setSendingNotif(false);
    setNotifSent(true);

    if (sendToTelegram) {
      setNotifResult(`Telegram: ${tgResult.success} отправлено, ${tgResult.failed} ошибок`);
    }

    setTimeout(() => {
      setNotifSent(false);
      setNotifResult('');
      setNotifTitle('');
      setNotifMessage('');
      setTargetChatId('');
    }, 3000);
  };

  return (
    <div className="page-transition px-4 py-4 space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="w-10 h-10 rounded-xl bg-bg flex items-center justify-center text-text hover:bg-stroke-soft transition-colors">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-xl font-bold text-text">Админ панель</h1>
          <p className="text-xs text-text-t">{orders.length} заказов • {formatByn(totalRevenue)} выручка</p>
        </div>
      </div>

      {/* Navigation tabs */}
      <div className="flex gap-2">
        {[
          { key: 'orders' as const, label: 'Заказы', icon: Package },
          { key: 'notifications' as const, label: 'Уведомления', icon: Bell },
          { key: 'stats' as const, label: 'Статистика', icon: Users },
        ].map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setActiveSection(key)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-xs font-medium transition-all ${
              activeSection === key
                ? 'bg-primary text-white'
                : 'bg-bg text-text-s hover:bg-stroke-soft'
            }`}
          >
            <Icon size={14} />
            {label}
          </button>
        ))}
      </div>

      {/* Orders Section */}
      {activeSection === 'orders' && (
        <div className="space-y-3 page-transition">
          <div className="relative">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-text-tertiary" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Поиск по ID или товару..."
              className="w-full h-11 rounded-xl border border-border bg-surface pl-10 pr-4 text-sm text-text placeholder:text-text-tertiary focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
            {[
              { key: 'all' as const, label: 'Все' },
              { key: 'pending' as const, label: '⏳ Ожидает' },
              { key: 'bought' as const, label: '🛒 Выкуплен' },
              { key: 'transit' as const, label: '✈️ В пути' },
              { key: 'delivered' as const, label: '✅ Доставлен' },
              { key: 'problem' as const, label: '⚠️ Проблема' },
            ].map(f => (
              <button
                key={f.key}
                onClick={() => setStatusFilter(f.key)}
                className={`shrink-0 px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                  statusFilter === f.key ? 'bg-primary text-white' : 'bg-bg text-text-secondary hover:bg-border-light'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="space-y-3">
            {filteredOrders.length === 0 ? (
              <KCard variant="filled" padding="lg" className="text-center">
                <p className="text-text-secondary text-sm">Заказов не найдено</p>
              </KCard>
            ) : filteredOrders.map(order => (
              <AdminOrderCard
                key={order.id}
                order={order}
                isExpanded={expandedOrder === order.id}
                onToggle={() => setExpandedOrder(prev => prev === order.id ? null : order.id)}
                onStatusChange={handleStatusChange}
              />
            ))}
          </div>
        </div>
      )}

      {/* Notifications Section */}
      {activeSection === 'notifications' && (
        <div className="space-y-4 page-transition">
          <KCard variant="default" padding="lg" className="space-y-4">
            <h3 className="font-semibold text-text">Отправить уведомление</h3>

            <div className="flex gap-2">
              <button
                onClick={() => setNotifTarget('all')}
                className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${
                  notifTarget === 'all'
                    ? 'bg-primary text-white'
                    : 'bg-bg text-text-s border border-stroke-soft'
                }`}
              >
                Всем пользователям
              </button>
              <button
                onClick={() => setNotifTarget('specific')}
                className={`flex-1 py-2 rounded-xl text-sm font-medium transition-all ${
                  notifTarget === 'specific'
                    ? 'bg-primary text-white'
                    : 'bg-bg text-text-s border border-stroke-soft'
                }`}
              >
                Конкретному
              </button>
            </div>

            {notifTarget === 'specific' && (
              <div className="space-y-3">
                <KInput
                  label="ID пользователя"
                  value={targetUserId}
                  onChange={(e) => setTargetUserId(e.target.value)}
                  placeholder="user_id"
                />
                <KInput
                  label="Telegram Chat ID (для отправки в TG)"
                  value={targetChatId}
                  onChange={(e) => setTargetChatId(e.target.value.replace(/\D/g, ''))}
                  placeholder="123456789"
                  hint="Можно найти в деталях заказа"
                />
              </div>
            )}

            <KInput
              label="Заголовок"
              value={notifTitle}
              onChange={(e) => setNotifTitle(e.target.value)}
              placeholder="Например: Акция!"
            />

            <KTextarea
              label="Сообщение"
              value={notifMessage}
              onChange={(e) => setNotifMessage(e.target.value)}
              placeholder="Текст уведомления..."
            />

            {/* Telegram toggle */}
            <label className="flex items-center gap-3 p-3 bg-bg rounded-xl cursor-pointer">
              <input
                type="checkbox"
                checked={sendToTelegram}
                onChange={(e) => setSendToTelegram(e.target.checked)}
                className="w-5 h-5 rounded border-stroke text-primary focus:ring-primary"
              />
              <div className="flex-1">
                <p className="text-sm font-medium text-text flex items-center gap-2">
                  <MessageCircle size={16} className="text-primary" />
                  Отправить в Telegram
                </p>
                <p className="text-xs text-text-t">Пользователь должен начать диалог с ботом</p>
              </div>
            </label>

            {notifResult && (
              <div className={`p-3 rounded-xl text-sm ${notifResult.includes('ошибок') && !notifResult.includes('0 ошибок') ? 'bg-warning/10 text-warning' : 'bg-success/10 text-success'}`}>
                {notifResult}
              </div>
            )}

            <KButton
              fullWidth
              loading={sendingNotif}
              disabled={!notifTitle.trim() || !notifMessage.trim()}
              onClick={handleSendNotification}
              icon={notifSent ? <Check size={18} /> : <Send size={18} />}
            >
              {notifSent ? 'Отправлено!' : sendingNotif ? 'Отправка...' : 'Отправить уведомление'}
            </KButton>
          </KCard>

          <div>
            <h3 className="font-semibold text-text mb-2">История уведомлений</h3>
            <NotificationHistory />
          </div>
        </div>
      )}

      {/* Stats Section */}
      {activeSection === 'stats' && (
        <div className="space-y-3 page-transition">
          <div className="grid grid-cols-2 gap-3">
            <KCard variant="filled" padding="md" className="text-center">
              <p className="text-2xl font-bold text-primary">{orders.length}</p>
              <p className="text-xs text-text-tertiary mt-1">Всего заказов</p>
            </KCard>
            <KCard variant="filled" padding="md" className="text-center">
              <p className="text-2xl font-bold text-success">{formatByn(totalRevenue)}</p>
              <p className="text-xs text-text-tertiary mt-1">Общая выручка</p>
            </KCard>
          </div>

          <KCard variant="default" padding="md">
            <h3 className="font-semibold text-text mb-3">Заказы по статусам</h3>
            <div className="space-y-2">
              {Object.entries(statusCounts).map(([status, count]) => (
                <div key={status} className="flex items-center justify-between p-2 bg-bg rounded-lg">
                  <StatusBadge status={status as OrderStatus} />
                  <span className="text-sm font-bold text-text">{count}</span>
                </div>
              ))}
            </div>
          </KCard>

          <KCard variant="default" padding="md">
            <h3 className="font-semibold text-text mb-3">Последние заказы</h3>
            <div className="space-y-2">
              {orders.slice(0, 5).map(order => (
                <div key={order.id} className="flex items-center justify-between p-2 bg-bg rounded-lg">
                  <div>
                    <p className="text-sm font-medium text-text">{order.id}</p>
                    <p className="text-xs text-text-t">{formatDate(order.createdAt)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-bold text-text">{formatByn(order.totalPriceByn)}</p>
                    <StatusBadge status={order.status} />
                  </div>
                </div>
              ))}
            </div>
          </KCard>
        </div>
      )}
    </div>
  );
}

function AdminOrderCard({
  order,
  isExpanded,
  onToggle,
  onStatusChange,
}: {
  order: Order;
  isExpanded: boolean;
  onToggle: () => void;
  onStatusChange: (orderId: string, status: OrderStatus) => void;
}) {
  const [isUpdating, setIsUpdating] = useState(false);

  const statuses: OrderStatus[] = ['pending', 'bought', 'consolidation', 'transit', 'customs', 'delivered_minsk', 'delivered', 'problem'];

  const handleChangeStatus = (newStatus: OrderStatus) => {
    setIsUpdating(true);
    setTimeout(() => {
      onStatusChange(order.id, newStatus);
      setIsUpdating(false);
    }, 300);
  };

  return (
    <KCard variant="elevated" padding="none" className="overflow-hidden">
      <div className="p-4 cursor-pointer" onClick={onToggle}>
        <div className="flex items-start justify-between mb-2">
          <div>
            <span className="font-bold text-text text-sm">{order.id}</span>
            <p className="text-xs text-text-tertiary mt-0.5">{formatDate(order.createdAt)}</p>
          </div>
          <div className="flex items-center gap-2">
            <StatusBadge status={order.status} />
            {isExpanded ? <ChevronUp size={16} className="text-text-tertiary" /> : <ChevronDown size={16} className="text-text-tertiary" />}
          </div>
        </div>
        <p className="text-sm text-text-secondary line-clamp-1 mb-2">
          {order.items.map(i => i.name).join(', ')}
        </p>
        <div className="flex items-center gap-3 text-xs text-text-tertiary">
          <span>{formatWeight(order.totalWeightKg)}</span>
          <span>{formatByn(order.totalPriceByn)}</span>
          <span>{getDeliveryMethodName(order.deliveryMethod)}</span>
        </div>
        <StatusProgress status={order.status} />
      </div>

      {isExpanded && (
        <div className="border-t border-border-light p-4 page-transition">
          {/* Customer info */}
          {(order.customerName || order.customerUsername || order.telegramChatId) && (
            <div className="mb-3 p-2 bg-bg rounded-lg">
              <p className="text-xs font-medium text-text-s mb-1">Клиент:</p>
              {order.customerName && <p className="text-sm text-text">{order.customerName}</p>}
              {order.customerUsername && <p className="text-xs text-primary">@{order.customerUsername}</p>}
              {order.telegramChatId && (
                <p className="text-xs text-text-t mt-1 flex items-center gap-1">
                  <MessageCircle size={10} />
                  Chat ID: {order.telegramChatId}
                </p>
              )}
            </div>
          )}

          <h4 className="text-sm font-semibold text-text mb-2">Товары:</h4>
          <div className="space-y-2 mb-4">
            {order.items.map(item => (
              <div key={item.id} className="flex items-start gap-3 p-2.5 bg-bg rounded-xl">
                <div className="w-10 h-10 bg-border-light rounded-lg flex items-center justify-center text-lg shrink-0">📦</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-text">{item.name}</p>
                  <p className="text-xs text-text-tertiary">¥{item.priceCny} × {item.quantity} | {item.weightKg} кг{item.color ? ` | ${item.color}` : ''}{item.size ? ` | ${item.size}` : ''}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mb-4">
            <h4 className="text-sm font-semibold text-text mb-2">Изменить статус:</h4>
            <div className="flex flex-wrap gap-1.5">
              {statuses.map(s => (
                <button
                  key={s}
                  onClick={() => handleChangeStatus(s)}
                  disabled={isUpdating || order.status === s}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    order.status === s
                      ? 'bg-primary text-white'
                      : 'bg-bg text-text-s hover:bg-stroke-soft border border-stroke-soft'
                  }`}
                >
                  {isUpdating && order.status !== s ? <RefreshCw size={10} className="animate-spin" /> : getStatusLabel(s)}
                </button>
              ))}
            </div>
          </div>

          {order.history.length > 0 && (
            <>
              <h4 className="text-sm font-semibold text-text mb-2">История:</h4>
              <div className="space-y-2">
                {[...order.history].reverse().map((entry) => (
                  <div key={entry.id} className="flex items-center gap-2 text-xs">
                    <span className="text-text-t">{formatDate(entry.timestamp)}</span>
                    <StatusBadge status={entry.status} />
                    <span className="text-text-s">{entry.description}</span>
                  </div>
                ))}
              </div>
            </>
          )}

          <div className="mt-4 p-3 bg-bg rounded-xl space-y-1.5 text-sm">
            <div className="flex justify-between"><span className="text-text-secondary">Товар:</span><span className="font-medium text-text">{formatByn(order.totalPriceCny * 0.53)}</span></div>
            <div className="flex justify-between"><span className="text-text-secondary">Доставка:</span><span className="font-medium text-text">{formatByn(order.deliveryPriceByn)}</span></div>
            <div className="border-t border-border pt-1.5 flex justify-between">
              <span className="font-bold text-text">Итого:</span>
              <span className="font-bold text-primary">{formatByn(order.totalPriceByn)}</span>
            </div>
          </div>
        </div>
      )}
    </KCard>
  );
}

function NotificationHistory() {
  const notifications = useNotificationStore((s) => s.notifications);

  if (notifications.length === 0) {
    return (
      <KCard variant="filled" padding="lg" className="text-center">
        <p className="text-text-secondary text-sm">История уведомлений пуста</p>
      </KCard>
    );
  }

  return (
    <div className="space-y-2">
      {notifications.slice(0, 20).map((n) => (
        <div key={n.id} className="p-3 bg-bg rounded-xl">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-text">{n.title}</p>
              <p className="text-xs text-text-t mt-0.5">{n.message}</p>
              <p className="text-[10px] text-text-t mt-1">
                {new Date(n.createdAt).toLocaleDateString('ru-BY', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                {' • '}
                {n.type === 'order' ? 'Заказ' : n.type === 'promo' ? 'Акция' : 'Системное'}
                {n.sentToTelegram && ' • Telegram'}
              </p>
            </div>
            {n.read && <span className="text-[10px] text-text-t bg-stroke-soft px-1.5 py-0.5 rounded">Прочитано</span>}
          </div>
        </div>
      ))}
    </div>
  );
}

function getStatusLabel(status: OrderStatus): string {
  const labels: Record<OrderStatus, string> = {
    pending: 'Ожидает выкупа',
    bought: 'Выкуплен',
    consolidation: 'Консолидация',
    transit: 'В пути',
    customs: 'Таможня',
    delivered_minsk: 'На складе (Минск)',
    delivered: 'Доставлен',
    problem: 'Проблема',
  };
  return labels[status];
}
