import { useState } from 'react';
import { useAuthStore } from '../store/authStore';
import { useOrderStore } from '../store/orderStore';
import { KCard } from '../components/ui/KCard';
import { KButton } from '../components/ui/KButton';
import { KInput, KTextarea } from '../components/ui/KInput';
import { formatByn, calculateDelivery, isValidChineseLink } from '../lib/helpers';
import type { OrderStep, DeliveryMethod, OrderItem } from '../types';
import { generateId } from '../types';
import { Link, Package, ArrowRight, ArrowLeft, Check, AlertCircle, Truck, Plane, ShoppingBag } from 'lucide-react';

export function OrderPage() {
  const user = useAuthStore((s) => s.user);
  const rates = useOrderStore((s) => s.rates);
  const createOrder = useOrderStore((s) => s.createOrder);

  const [step, setStep] = useState<OrderStep>('link');
  const [link, setLink] = useState('');
  const [orderMethod, setOrderMethod] = useState<'link' | 'text'>('link');
  const [deliveryMethod, setDeliveryMethod] = useState<DeliveryMethod>('air');

  const [itemName, setItemName] = useState('');
  const [itemPrice, setItemPrice] = useState('');
  const [itemWeight, setItemWeight] = useState('');
  const [itemQuantity, setItemQuantity] = useState('1');
  const [itemColor, setItemColor] = useState('');
  const [itemSize, setItemSize] = useState('');
  const [itemNotes, setItemNotes] = useState('');
  const [isParsing, setIsParsing] = useState(false);
  const [orderCreated, setOrderCreated] = useState(false);

  const steps: { key: OrderStep; num: number }[] = [
    { key: 'link', num: 1 },
    { key: 'details', num: 2 },
    { key: 'confirm', num: 3 },
  ];
  const currentStepIdx = steps.findIndex(s => s.key === step);

  const handleParseLink = () => {
    if (!link.trim()) return;
    setIsParsing(true);
    setTimeout(() => {
      setItemName('Беспроводные наушники с активным шумоподавлением (Bluetooth 5.3)');
      setItemPrice('199');
      setItemWeight('0.35');
      setItemColor('Тёмно-синий');
      setIsParsing(false);
      setStep('details');
    }, 1500);
  };

  const priceNum = parseFloat(itemPrice) || 0;
  const weightNum = parseFloat(itemWeight) || 0;
  const qtyNum = parseInt(itemQuantity) || 1;

  const calculation = weightNum > 0
    ? calculateDelivery({ weightKg: weightNum, priceCny: priceNum, deliveryMethod }, rates)
    : null;

  const handleCreate = () => {
    const items: OrderItem[] = [{
      id: generateId(),
      orderId: '',
      name: itemName,
      link: link || undefined,
      priceCny: priceNum,
      weightKg: weightNum,
      quantity: qtyNum,
      color: itemColor || undefined,
      size: itemSize || undefined,
      notes: itemNotes || undefined,
      status: 'pending',
    }];
    createOrder(
      items,
      deliveryMethod,
      `${user?.firstName || 'Клиент'} ${user?.lastName || ''}`.trim(),
      user?.username,
      user?.telegramId,
    );
    setOrderCreated(true);
  };

  const resetForm = () => {
    setOrderCreated(false);
    setStep('link');
    setLink('');
    setItemName('');
    setItemPrice('');
    setItemWeight('');
    setItemColor('');
    setItemSize('');
    setItemNotes('');
    setItemQuantity('1');
  };

  if (orderCreated) {
    return (
      <div className="page-transition px-4 py-8 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-20 h-20 bg-success/10 rounded-full flex items-center justify-center mb-4">
          <Check size={40} className="text-success" />
        </div>
        <h2 className="text-xl font-bold text-text mb-2">Заказ создан!</h2>
        <p className="text-text-secondary text-center text-sm mb-6 max-w-[280px]">
          Мы получили ваш заказ. Менеджер свяжется для подтверждения. Отслеживайте статус во вкладке «Посылки».
        </p>
        <KButton variant="primary" onClick={resetForm} icon={<ShoppingBag size={18} />}>
          Новый заказ
        </KButton>
      </div>
    );
  }

  return (
    <div className="page-transition px-4 py-4 space-y-4">
      {/* Шаги */}
      <div className="flex items-center px-2">
        {steps.map((s, i) => (
          <div key={s.key} className="flex items-center flex-1">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-all ${
              i <= currentStepIdx ? 'bg-primary text-white' : 'bg-bg text-text-tertiary border border-border'
            }`}>
              {i < currentStepIdx ? <Check size={16} /> : s.num}
            </div>
            {i < steps.length - 1 && (
              <div className={`flex-1 h-0.5 mx-3 rounded ${i < currentStepIdx ? 'bg-primary' : 'bg-border-light'}`} />
            )}
          </div>
        ))}
      </div>

      {/* Шаг 1: Ссылка или текст */}
      {step === 'link' && (
        <div className="space-y-4 page-transition">
          <h2 className="text-lg font-bold text-text">Откуда товар?</h2>
          <div className="flex gap-2">
            <button onClick={() => setOrderMethod('link')} className={`flex-1 flex items-center justify-center gap-2 h-12 rounded-xl border-2 font-medium text-sm transition-all ${orderMethod === 'link' ? 'border-primary bg-primary/5 text-primary' : 'border-border text-text-secondary'}`}>
              <Link size={16} /> По ссылке
            </button>
            <button onClick={() => setOrderMethod('text')} className={`flex-1 flex items-center justify-center gap-2 h-12 rounded-xl border-2 font-medium text-sm transition-all ${orderMethod === 'text' ? 'border-primary bg-primary/5 text-primary' : 'border-border text-text-secondary'}`}>
              <Package size={16} /> Вручную
            </button>
          </div>

          {orderMethod === 'link' ? (
            <KCard variant="default" padding="lg">
              <KInput label="Ссылка на товар" value={link} onChange={(e) => setLink(e.target.value)} placeholder="https://taobao.com/item/..." leftIcon={<Link size={16} />} />
              {link && !isValidChineseLink(link) && (
                <div className="flex items-center gap-1.5 mt-2 text-warning text-xs">
                  <AlertCircle size={12} /> Ссылка может быть не с поддерживаемой площадки
                </div>
              )}
              <KButton variant="primary" fullWidth className="mt-4" loading={isParsing} onClick={handleParseLink} disabled={!link.trim()} icon={<ArrowRight size={18} />}>
                {isParsing ? 'AI анализирует товар...' : 'Разобрать товар'}
              </KButton>
              <p className="text-xs text-text-tertiary mt-2 text-center">AI автоматически определит название, цену и вес</p>
            </KCard>
          ) : (
            <KCard variant="default" padding="lg">
              <p className="text-sm text-text-secondary mb-3">Введите характеристики товара вручную</p>
              <KButton variant="primary" fullWidth onClick={() => setStep('details')} icon={<ArrowRight size={18} />}>
                Ввести характеристики
              </KButton>
            </KCard>
          )}
        </div>
      )}

      {/* Шаг 2: Характеристики */}
      {step === 'details' && (
        <div className="space-y-3 page-transition">
          <h2 className="text-lg font-bold text-text">Характеристики</h2>
          <KCard variant="default" padding="lg" className="space-y-3">
            <KInput label="Название товара" value={itemName} onChange={(e) => setItemName(e.target.value)} placeholder="Например: Наушники Bluetooth" />
            <div className="grid grid-cols-2 gap-3">
              <KInput label="Цена (¥)" type="number" value={itemPrice} onChange={(e) => setItemPrice(e.target.value)} placeholder="0" />
              <KInput label="Вес (кг)" type="number" value={itemWeight} onChange={(e) => setItemWeight(e.target.value)} placeholder="0.0" step="0.1" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <KInput label="Количество" type="number" value={itemQuantity} onChange={(e) => setItemQuantity(e.target.value)} placeholder="1" min="1" />
              <KInput label="Цвет" value={itemColor} onChange={(e) => setItemColor(e.target.value)} placeholder="Необязательно" />
            </div>
            <KInput label="Размер" value={itemSize} onChange={(e) => setItemSize(e.target.value)} placeholder="Необязательно" />
            <KTextarea label="Комментарий" value={itemNotes} onChange={(e) => setItemNotes(e.target.value)} placeholder="Пожелания к заказу..." />
          </KCard>
          <div className="flex gap-3">
            <KButton variant="secondary" onClick={() => setStep('link')} icon={<ArrowLeft size={16} />}>Назад</KButton>
            <KButton variant="primary" fullWidth onClick={() => setStep('confirm')} disabled={!itemName.trim() || !itemPrice || !itemWeight} icon={<ArrowRight size={18} />}>Далее</KButton>
          </div>
        </div>
      )}

      {/* Шаг 3: Подтверждение */}
      {step === 'confirm' && (
        <div className="space-y-4 page-transition">
          <h2 className="text-lg font-bold text-text">Подтверждение</h2>

          <KCard variant="default" padding="lg">
            <h3 className="font-semibold text-text mb-3">{itemName}</h3>
            <div className="space-y-1.5 text-sm">
              <div className="flex justify-between"><span className="text-text-secondary">Цена:</span><span className="font-medium">¥{priceNum} × {qtyNum} = ¥{priceNum * qtyNum}</span></div>
              <div className="flex justify-between"><span className="text-text-secondary">Вес:</span><span className="font-medium">{weightNum} кг × {qtyNum} = {(weightNum * qtyNum).toFixed(1)} кг</span></div>
              {itemColor && <div className="flex justify-between"><span className="text-text-secondary">Цвет:</span><span className="font-medium">{itemColor}</span></div>}
              {itemSize && <div className="flex justify-between"><span className="text-text-secondary">Размер:</span><span className="font-medium">{itemSize}</span></div>}
            </div>
          </KCard>

          <KCard variant="default" padding="lg">
            <h3 className="font-semibold text-text mb-3">Доставка</h3>
            <div className="space-y-2">
              {([
                { key: 'air' as DeliveryMethod, label: 'Авиа', icon: Plane, price: rates.airPerKg, days: '5-7 дней' },
                { key: 'auto' as DeliveryMethod, label: 'Авто', icon: Truck, price: rates.autoPerKg, days: '18-25 дней' },
              ]).map(m => (
                <button key={m.key} onClick={() => setDeliveryMethod(m.key)} className={`w-full flex items-center gap-3 p-3 rounded-xl border-2 transition-all ${deliveryMethod === m.key ? 'border-primary bg-primary/5' : 'border-border-light hover:border-border'}`}>
                  <m.icon size={20} className={deliveryMethod === m.key ? 'text-primary' : 'text-text-tertiary'} />
                  <div className="flex-1 text-left">
                    <p className={`text-sm font-medium ${deliveryMethod === m.key ? 'text-primary' : 'text-text'}`}>{m.label}</p>
                    <p className="text-xs text-text-tertiary">{m.days}</p>
                  </div>
                  <span className="text-sm font-semibold text-text">{m.price} BYN/кг</span>
                </button>
              ))}
            </div>
          </KCard>

          {calculation && (
            <KCard variant="filled" padding="lg">
              <h3 className="font-semibold text-text mb-3">Итого</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-text-secondary">Товар (¥{priceNum * qtyNum})</span><span className="font-medium text-text">{formatByn(calculation.productCostByn * qtyNum)}</span></div>
                <div className="flex justify-between"><span className="text-text-secondary">Доставка ({(weightNum * qtyNum).toFixed(1)} кг)</span><span className="font-medium text-text">{formatByn(calculation.deliveryCostByn * qtyNum)}</span></div>
                <div className="border-t border-border pt-2 flex justify-between">
                  <span className="font-bold text-text">К оплате</span>
                  <span className="text-xl font-bold text-primary">{formatByn(calculation.totalByn * qtyNum)}</span>
                </div>
              </div>
            </KCard>
          )}

          <div className="flex gap-3">
            <KButton variant="secondary" onClick={() => setStep('details')} icon={<ArrowLeft size={16} />}>Назад</KButton>
            <KButton variant="primary" fullWidth onClick={handleCreate} icon={<Check size={18} />}>Оформить заказ</KButton>
          </div>
        </div>
      )}
    </div>
  );
}
