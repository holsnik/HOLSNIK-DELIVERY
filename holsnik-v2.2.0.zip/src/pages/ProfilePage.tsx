import { useState } from 'react';
import { KCard } from '../components/ui/KCard';
import { KButton } from '../components/ui/KButton';
import { KInput } from '../components/ui/KInput';
import { useAuthStore } from '../store/authStore';
import { useOrderStore } from '../store/orderStore';
import { useNotificationStore } from '../store/notificationStore';
import { formatByn } from '../lib/helpers';
import { CONFIG } from '../lib/config';
import { Truck, HelpCircle, ChevronRight, ChevronDown, ExternalLink, LogOut, Edit2, Check, X, Bell, Shield, User } from 'lucide-react';

interface ProfilePageProps {
  onNavigateTracking: () => void;
  onLogout: () => void;
  onNavigateAdmin?: () => void;
}

export function ProfilePage({ onNavigateTracking, onLogout, onNavigateAdmin }: ProfilePageProps) {
  const user = useAuthStore((s) => s.user);
  const authMethod = useAuthStore((s) => s.method);
  const updateProfile = useAuthStore((s) => s.updateProfile);
  const orders = useOrderStore((s) => s.orders);
  const rates = useOrderStore((s) => s.rates);
  const notifications = useNotificationStore((s) => s.notifications);
  const unreadCount = useNotificationStore((s) => s.getUnreadCount());

  const [isEditingName, setIsEditingName] = useState(false);
  const [editFirstName, setEditFirstName] = useState(user?.firstName || '');
  const [editLastName, setEditLastName] = useState(user?.lastName || '');
  const [showNotifications, setShowNotifications] = useState(false);

  const totalSpent = orders.reduce((sum, o) => sum + o.totalPriceByn, 0);
  const deliveredCount = orders.filter(o => o.status === 'delivered').length;
  const activeCount = orders.filter(o => !['delivered', 'problem'].includes(o.status)).length;
  const isAdmin = user?.isAdmin === true;

  const handleSaveName = () => {
    if (editFirstName.trim()) {
      updateProfile({
        firstName: editFirstName.trim(),
        lastName: editLastName.trim() || undefined,
      });
      setIsEditingName(false);
    }
  };

  const handleCancelEdit = () => {
    setEditFirstName(user?.firstName || '');
    setEditLastName(user?.lastName || '');
    setIsEditingName(false);
  };

  const userNotifications = notifications
    .filter(n => n.userId === user?.id)
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return (
    <div className="page-transition px-4 py-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold text-text">Профиль</h1>
        <button
          onClick={() => setShowNotifications(!showNotifications)}
          className="relative w-10 h-10 rounded-xl bg-surface border border-stroke-soft flex items-center justify-center text-text-s hover:bg-bg transition-colors"
        >
          <Bell size={18} />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 w-5 h-5 bg-error text-white text-[10px] font-bold rounded-full flex items-center justify-center">
              {unreadCount}
            </span>
          )}
        </button>
      </div>

      {/* Уведомления */}
      {showNotifications && (
        <KCard variant="elevated" padding="md" className="page-transition">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-text text-sm">Уведомления</h3>
            {unreadCount > 0 && (
              <button
                onClick={() => useNotificationStore.getState().markAllAsRead()}
                className="text-xs text-primary font-medium"
              >
                Прочитать все
              </button>
            )}
          </div>
          {userNotifications.length === 0 ? (
            <p className="text-sm text-text-t text-center py-4">Уведомлений пока нет</p>
          ) : (
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {userNotifications.map((n) => (
                <div
                  key={n.id}
                  onClick={() => useNotificationStore.getState().markAsRead(n.id)}
                  className={`p-3 rounded-xl cursor-pointer transition-colors ${
                    n.read ? 'bg-bg' : 'bg-primary/5 border border-primary/10'
                  }`}
                >
                  <div className="flex items-start gap-2">
                    <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${n.read ? 'bg-stroke' : 'bg-primary'}`} />
                    <div className="flex-1 min-w-0">
                      <p className={`text-sm font-medium ${n.read ? 'text-text-s' : 'text-text'}`}>{n.title}</p>
                      <p className="text-xs text-text-t mt-0.5">{n.message}</p>
                      <p className="text-[10px] text-text-t mt-1">
                        {new Date(n.createdAt).toLocaleDateString('ru-BY', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </KCard>
      )}

      {/* Карточка пользователя */}
      <KCard variant="elevated" padding="lg">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center text-primary font-bold text-xl">
            {user?.firstName?.[0] || '?'}
          </div>
          <div className="flex-1 min-w-0">
            {isEditingName ? (
              <div className="space-y-2">
                <KInput
                  value={editFirstName}
                  onChange={(e) => setEditFirstName(e.target.value)}
                  placeholder="Имя"
                  className="h-9 text-sm"
                />
                <KInput
                  value={editLastName}
                  onChange={(e) => setEditLastName(e.target.value)}
                  placeholder="Фамилия"
                  className="h-9 text-sm"
                />
                <div className="flex gap-2">
                  <button
                    onClick={handleSaveName}
                    className="flex-1 h-8 rounded-lg bg-primary text-white text-xs font-medium flex items-center justify-center gap-1"
                  >
                    <Check size={14} /> Сохранить
                  </button>
                  <button
                    onClick={handleCancelEdit}
                    className="flex-1 h-8 rounded-lg bg-stroke-soft text-text-s text-xs font-medium flex items-center justify-center gap-1"
                  >
                    <X size={14} /> Отмена
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-text truncate">
                    {user?.firstName} {user?.lastName || ''}
                  </h2>
                  <button
                    onClick={() => setIsEditingName(true)}
                    className="w-7 h-7 rounded-lg bg-bg flex items-center justify-center text-text-t hover:text-primary transition-colors"
                    title="Изменить имя"
                  >
                    <Edit2 size={13} />
                  </button>
                </div>
                {user?.username && <p className="text-sm text-primary">@{user.username}</p>}
                {user?.phone && <p className="text-sm text-text-secondary">{user.phone}</p>}
              </>
            )}
          </div>
          {authMethod === 'telegram' && (
            <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full font-medium shrink-0">Telegram</span>
          )}
        </div>
        {isAdmin && (
          <div className="mt-3 pt-3 border-t border-stroke-soft">
            <div className="flex items-center gap-2 text-warning">
              <Shield size={16} />
              <span className="text-sm font-medium">Администратор</span>
            </div>
          </div>
        )}
      </KCard>

      {/* Статистика */}
      <div className="grid grid-cols-3 gap-2">
        <KCard variant="filled" padding="sm" className="text-center cursor-pointer" onClick={onNavigateTracking}>
          <p className="text-xl font-bold text-primary">{orders.length}</p>
          <p className="text-[10px] text-text-tertiary">Заказов</p>
        </KCard>
        <KCard variant="filled" padding="sm" className="text-center">
          <p className="text-xl font-bold text-warning">{activeCount}</p>
          <p className="text-[10px] text-text-tertiary">В пути</p>
        </KCard>
        <KCard variant="filled" padding="sm" className="text-center">
          <p className="text-xl font-bold text-success">{deliveredCount}</p>
          <p className="text-[10px] text-text-tertiary">Доставлено</p>
        </KCard>
      </div>

      {/* Админ панель — только для админов */}
      {isAdmin && onNavigateAdmin && (
        <button onClick={onNavigateAdmin} className="w-full">
          <KCard variant="default" padding="md" className="hover:bg-bg/50 transition-colors text-left border-warning/30 bg-warning/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-warning/10 flex items-center justify-center">
                  <Shield size={20} className="text-warning" />
                </div>
                <div>
                  <p className="font-semibold text-text text-sm">Панель администратора</p>
                  <p className="text-xs text-text-tertiary">Управление заказами и уведомления</p>
                </div>
              </div>
              <ChevronRight size={18} className="text-text-tertiary" />
            </div>
          </KCard>
        </button>
      )}

      {/* Мои заказы */}
      <button onClick={onNavigateTracking} className="w-full">
        <KCard variant="default" padding="md" className="hover:bg-bg/50 transition-colors text-left">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-xl">📦</span>
              <div>
                <p className="font-semibold text-text text-sm">Мои заказы</p>
                {orders.length > 0
                  ? <p className="text-xs text-text-tertiary">{formatByn(totalSpent)} всего</p>
                  : <p className="text-xs text-text-tertiary">Ещё нет заказов</p>
                }
              </div>
            </div>
            <ChevronRight size={18} className="text-text-tertiary" />
          </div>
        </KCard>
      </button>

      {/* Тарифы */}
      <KCard variant="default" padding="md">
        <div className="flex items-center gap-2 mb-3">
          <Truck size={18} className="text-primary" />
          <p className="font-semibold text-text text-sm">Тарифы доставки</p>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between items-center p-2 bg-bg rounded-lg">
            <div>
              <span className="text-sm font-medium text-text">✈️ Авиа</span>
              <span className="text-xs text-text-tertiary ml-2">5-7 дней</span>
            </div>
            <span className="text-sm font-bold text-text">$15/кг</span>
          </div>
          <div className="flex justify-between items-center p-2 bg-bg rounded-lg">
            <div>
              <span className="text-sm font-medium text-text">🚚 Авто</span>
              <span className="text-xs text-text-tertiary ml-2">18-25 дней</span>
            </div>
            <span className="text-sm font-bold text-text">$7/кг</span>
          </div>
          <div className="flex justify-between items-center p-2 bg-bg rounded-lg">
            <span className="text-sm text-text-secondary">Курс CNY → BYN</span>
            <span className="text-sm font-bold text-primary">{rates.cnyToByn}</span>
          </div>
        </div>
      </KCard>

      {/* Написать в поддержку */}
      <a href={CONFIG.SUPPORT_LINK} target="_blank" rel="noopener noreferrer">
        <KCard variant="default" padding="md" className="hover:bg-bg/50 transition-colors">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-xl">💬</span>
              <div>
                <p className="font-semibold text-text text-sm">Написать в поддержку</p>
                <p className="text-xs text-text-tertiary">@{CONFIG.BOT_USERNAME}</p>
              </div>
            </div>
            <ExternalLink size={16} className="text-primary" />
          </div>
        </KCard>
      </a>

      {/* FAQ */}
      <FaqSection />

      {/* Подвал */}
      <div className="text-center pt-2 pb-4">
        <p className="text-sm font-semibold text-text">{CONFIG.COMPANY_NAME}</p>
        <p className="text-xs text-text-tertiary mt-1">{CONFIG.COMPANY_DESC} • v{CONFIG.VERSION} • {CONFIG.YEAR}</p>
      </div>

      {/* Выход — только для телефонной авторизации */}
      {authMethod === 'phone' && (
        <KButton variant="outline" fullWidth onClick={onLogout} icon={<LogOut size={18} />}>
          Выйти
        </KButton>
      )}
    </div>
  );
}

/** FAQ — аккордеон */
function FaqSection() {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  return (
    <KCard variant="default" padding="md">
      <div className="flex items-center gap-2 mb-3">
        <HelpCircle size={18} className="text-primary" />
        <p className="font-semibold text-text text-sm">Частые вопросы</p>
      </div>
      <div className="space-y-1">
        {FAQ_ITEMS.map((faq, i) => (
          <div key={i}>
            <button
              onClick={() => setOpenIdx(openIdx === i ? null : i)}
              className="w-full flex items-start justify-between gap-2 py-2.5 text-left"
            >
              <span className="text-sm text-text font-medium leading-snug">{faq.q}</span>
              <ChevronDown
                size={16}
                className={`text-text-tertiary shrink-0 mt-0.5 transition-transform ${openIdx === i ? 'rotate-180' : ''}`}
              />
            </button>
            {openIdx === i && (
              <p className="text-sm text-text-secondary leading-relaxed pb-2 page-transition">{faq.a}</p>
            )}
            {i < FAQ_ITEMS.length - 1 && <div className="border-b border-border-light" />}
          </div>
        ))}
      </div>
    </KCard>
  );
}

const FAQ_ITEMS = [
  { q: 'Как сделать заказ?', a: 'Нажмите вкладку «Заказ», вставьте ссылку на товар с Taobao, 1688 или Tmall. AI автоматически определит название и цену. Заполните характеристики и подтвердите.' },
  { q: 'Сколько стоит доставка?', a: 'Авиа: $15/кг (49 BYN, 5-7 дней), Авто: $7/кг (22.9 BYN, 18-25 дней). Таможня включена в стоимость.' },
  { q: 'Как оплатить?', a: 'Картой (Белкарт, Visa, Mastercard), через ЕРИП или наличными при получении. Предоплата 100% при оформлении.' },
  { q: 'Как отслеживать посылку?', a: 'Во вкладке «Посылки» — все заказы с актуальными статусами и историей перемещений.' },
  { q: 'Можно ли оформить возврат?', a: 'Да! Пока товар на складе в Китае (статус «Выкуплен» или «Консолидация»), откройте «Посылки», нажмите ↩️ рядом с товаром и укажите причину. Менеджер организует возврат или замену.' },
  { q: 'Есть ли ограничения по весу?', a: 'Авиа: до 30 кг. Авто: до 50 кг. Для крупногабаритных грузов — пишите в поддержку для индивидуального расчёта.' },
];
