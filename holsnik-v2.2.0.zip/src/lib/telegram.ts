import { CONFIG } from './config';

/**
 * Отправка уведомлений менеджеру через Telegram Bot API.
 * Вызывается при новом заказе и при запросе возврата/брака.
 */

interface TgMessage {
  text: string;
  parse_mode?: 'HTML' | 'Markdown';
}

async function sendToManager(msg: TgMessage): Promise<boolean> {
  const url = `https://api.telegram.org/bot${CONFIG.BOT_TOKEN}/sendMessage`;
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: CONFIG.MANAGER_CHAT_ID,
        text: msg.text,
        parse_mode: msg.parse_mode ?? 'HTML',
      }),
    });
    const data = await res.json();
    if (!data.ok) {
      console.error('[TG Notify]', data.description);
    }
    return data.ok;
  } catch (err) {
    console.error('[TG Notify] Failed:', err);
    return false;
  }
}

/** Уведомление: новый заказ */
export function notifyNewOrder(params: {
  orderId: string;
  userName: string;
  username?: string;
  items: { name: string; priceCny: number; quantity: number; weightKg: number }[];
  deliveryMethod: string;
  totalByn: number;
  totalCny: number;
}): Promise<boolean> {
  const itemsList = params.items
    .map(i => `  • ${i.name} — ¥${i.priceCny} × ${i.quantity} (${i.weightKg} кг)`)
    .join('\n');

  return sendToManager({
    text: `🆕 <b>Новый заказ!</b>

📋 <b>${params.orderId}</b>
👤 ${params.userName}${params.username ? ` (${params.username})` : ''}

<b>Товары:</b>
${itemsList}

🚚 Доставка: ${params.deliveryMethod}
💰 Итого: ¥${params.totalCny} / ${params.totalByn.toFixed(2)} BYN

${CONFIG.MANAGER_USERNAME}`,
  });
}

/** Уведомление: запрос возврата/брак */
export function notifyReturnRequest(params: {
  orderId: string;
  itemId: string;
  itemName: string;
  reason: string;
  userName: string;
  username?: string;
  comment?: string;
}): Promise<boolean> {
  return sendToManager({
    text: `⚠️ <b>Запрос на возврат/брак!</b>

📋 Заказ: <b>${params.orderId}</b>
📦 Товар: ${params.itemName}
❓ Причина: ${params.reason}
👤 ${params.userName}${params.username ? ` (${params.username})` : ''}
${params.comment ? `💬 Комментарий: ${params.comment}` : ''}

${CONFIG.MANAGER_USERNAME}`,
  });
}

/**
 * Отправить уведомление покупателю в Telegram.
 * 
 * ВАЖНО: Для личных сообщений с ботом, chat_id === user_id.
 * Пользователь должен сначала нажать /start у бота, иначе сообщение не дойдёт.
 * 
 * @param params.chatId - Telegram user_id (из initDataUnsafe.user.id)
 * @param params.title - Заголовок уведомления
 * @param params.message - Текст сообщения
 */
export async function notifyUser(params: {
  chatId: number;
  title: string;
  message: string;
  parse_mode?: 'HTML' | 'Markdown';
}): Promise<boolean> {
  const url = `https://api.telegram.org/bot${CONFIG.BOT_TOKEN}/sendMessage`;
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: params.chatId,
        text: `<b>${params.title}</b>\n\n${params.message}`,
        parse_mode: params.parse_mode ?? 'HTML',
        disable_notification: false,
      }),
    });
    const data = await res.json();
    if (!data.ok) {
      console.error('[TG User Notify]', data.description);
      // Если пользователь не начал диалог с ботом
      if (data.description?.includes('chat not found')) {
        console.warn(`[TG User Notify] Пользователь ${params.chatId} не начал диалог с ботом. Отправьте ему ссылку на бота сначала.`);
      }
    }
    return data.ok;
  } catch (err) {
    console.error('[TG User Notify] Failed:', err);
    return false;
  }
}

/**
 * Отправить массовое уведомление всем указанным пользователям.
 * 
 * @param params.chatIds - Массив Telegram user_id
 * @param params.title - Заголовок
 * @param params.message - Текст сообщения
 */
export async function notifyUsersBulk(params: {
  chatIds: number[];
  title: string;
  message: string;
}): Promise<{ success: number; failed: number; errors: string[] }> {
  let success = 0;
  let failed = 0;
  const errors: string[] = [];

  for (const chatId of params.chatIds) {
    const ok = await notifyUser({
      chatId,
      title: params.title,
      message: params.message,
    });
    if (ok) success++;
    else {
      failed++;
      errors.push(`chat_id ${chatId}: failed`);
    }
  }

  return { success, failed, errors };
}
