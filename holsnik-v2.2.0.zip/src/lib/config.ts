/**
 * ═══════════════════════════════════════════════════════
 *  КОНФИГУРАЦИЯ HOLSNICK DELIVERY
 * ═══════════════════════════════════════════════════════
 *
 *  КАК ПОДКЛЮЧИТЬ:
 *  1. @BotFather → /newbot → задайте имя
 *  2. /newapp → вставьте ссылку на хостинг
 *  3. Всё — при открытии из TG пользователь авторизуется
 *
 *  НИЖЕ УЖЕ ВАШИ ДАННЫЕ — можно деплоить как есть
 * ═══════════════════════════════════════════════════════
 */

export const CONFIG = {
  /** Telegram Bot */
  BOT_TOKEN: '8723083837:AAGHdKyTWQ6hY1p-ZGJQdrCYhoYW3-s_bJU',
  ADMIN_ID: 6250745595,
  MANAGER_USERNAME: '@holsnik',
  MANAGER_CHAT_ID: 6250745595,

  BOT_USERNAME: 'holsnik',
  SUPPORT_LINK: 'https://t.me/holsnik',

  COMPANY_NAME: 'Holsnik Delivery',
  COMPANY_DESC: 'Доставка из Китая в Беларусь',
  VERSION: '2.2.0',
  YEAR: 2026,

  /** Настройки администратора */
  ADMIN_SETTINGS: {
    /** ID Telegram пользователей с правами админа */
    ADMIN_IDS: [6250745595],
    /** Включить ли админ-панель */
    ENABLE_ADMIN_PANEL: true,
    /** Максимальное количество уведомлений в истории */
    MAX_NOTIFICATIONS_HISTORY: 100,
  },
};
