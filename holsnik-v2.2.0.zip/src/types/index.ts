/** === Core Types for Holsnik Delivery === */

/** Статусы заказа */
export type OrderStatus =
  | 'pending'
  | 'bought'
  | 'consolidation'
  | 'transit'
  | 'customs'
  | 'delivered_minsk'
  | 'delivered'
  | 'problem';

/** Способ доставки */
export type DeliveryMethod = 'air' | 'auto';

/** Метод авторизации */
export type AuthMethod = 'telegram' | 'phone';

/** Вкладки навигации */
export type TabName = 'home' | 'order' | 'tracking' | 'photos' | 'profile' | 'admin';

/** Шаги заказа */
export type OrderStep = 'link' | 'details' | 'confirm';

/** Элемент заказа (товар) */
export interface OrderItem {
  id: string;
  orderId: string;
  name: string;
  nameCn?: string;
  link?: string;
  imageUrl?: string;
  priceCny: number;
  weightKg: number;
  quantity: number;
  color?: string;
  size?: string;
  notes?: string;
  status: OrderStatus;
  returnRequested?: boolean;
  returnReason?: string;
  returnComment?: string;
}

/** Заказ */
export interface Order {
  id: string;
  userId: string;
  items: OrderItem[];
  status: OrderStatus;
  deliveryMethod: DeliveryMethod;
  totalPriceCny: number;
  totalPriceByn: number;
  deliveryPriceByn: number;
  commissionByn: number;
  totalWeightKg: number;
  trackingNumber?: string;
  createdAt: string;
  updatedAt: string;
  deliveredAt?: string;
  history: TrackingEntry[];
  /** Telegram chat ID для уведомлений */
  telegramChatId?: number;
  /** Имя пользователя для отображения */
  customerName?: string;
  /** Username Telegram */
  customerUsername?: string;
}

/** Запись трекинга (история статусов) */
export interface TrackingEntry {
  id: string;
  orderId: string;
  status: OrderStatus;
  description: string;
  timestamp: string;
  location?: string;
}

/** Фотоотчёт */
export interface PhotoReport {
  id: string;
  orderId: string;
  itemId: string;
  imageUrl: string;
  status: 'ok' | 'problem' | 'pending';
  comment?: string;
  uploadedAt: string;
}

/** Профиль пользователя */
export interface UserProfile {
  id: string;
  telegramId?: number;
  firstName: string;
  lastName?: string;
  username?: string;
  phone?: string;
  avatarUrl?: string;
  language: 'ru' | 'en';
  createdAt: string;
  /** Является ли пользователь админом */
  isAdmin?: boolean;
}

/** Сообщение чата с AI */
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

/** Уведомление для пользователя */
export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'order' | 'system' | 'promo';
  read: boolean;
  createdAt: string;
  /** ID заказа (если уведомление связано с заказом) */
  orderId?: string;
  /** Отправлено ли в Telegram */
  sentToTelegram?: boolean;
}

/** Тарифы доставки */
export interface DeliveryRates {
  airPerKg: number;     // BYN за кг (авиа)
  autoPerKg: number;    // BYN за кг (авто)
  commissionRate: number; // % комиссии
  cnyToByn: number;     // Курс CNY -> BYN
}

/** Данные калькулятора */
export interface CalculatorData {
  weightKg: number;
  priceCny: number;
  deliveryMethod: DeliveryMethod;
}

/** Результат калькуляции */
export interface CalculationResult {
  deliveryCostByn: number;
  commissionByn: number;
  productCostByn: number;
  totalByn: number;
}

/** Конфигурация статуса для UI */
export interface StatusConfig {
  label: string;
  color: string;
  bgColor: string;
  icon: string;
  step: number;
}

/** Маппинг статусов */
export const STATUS_MAP: Record<OrderStatus, StatusConfig> = {
  pending:        { label: 'Ожидает выкупа',   color: '#5F6368', bgColor: '#F1F3F4', icon: '⏳', step: 0 },
  bought:         { label: 'Выкуплен',          color: '#1A73E8', bgColor: '#E8F0FE', icon: '🛒', step: 1 },
  consolidation:  { label: 'Консолидация',      color: '#9C27B0', bgColor: '#F3E5F5', icon: '📦', step: 2 },
  transit:        { label: 'В пути',            color: '#FBBC04', bgColor: '#FEF7E0', icon: '✈️', step: 3 },
  customs:        { label: 'Таможня',           color: '#FF6D00', bgColor: '#FFF3E0', icon: '🏛️', step: 4 },
  delivered_minsk: { label: 'На складе (Минск)', color: '#34A853', bgColor: '#E6F4EA', icon: '🏪', step: 5 },
  delivered:      { label: 'Доставлен',         color: '#34A853', bgColor: '#E6F4EA', icon: '✅', step: 6 },
  problem:        { label: 'Проблема',          color: '#EA4335', bgColor: '#FCE8E6', icon: '⚠️', step: -1 },
};

/** Тарифы по умолчанию */
export const DEFAULT_RATES: DeliveryRates = {
  airPerKg: 49,       // $15/кг
  autoPerKg: 22.9,    // $7/кг
  commissionRate: 0,  // без комиссии
  cnyToByn: 0.53,
};

/** Вспомогательная функция — генерация ID */
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}
