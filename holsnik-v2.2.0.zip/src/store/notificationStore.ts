import { create } from 'zustand';
import type { Notification } from '../types';
import { generateId } from '../types';

const NOTIFICATIONS_KEY = 'holsnik_notifications';

function loadNotifications(): Notification[] {
  try {
    const saved = localStorage.getItem(NOTIFICATIONS_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

function saveNotifications(notifications: Notification[]): void {
  try {
    localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifications));
  } catch { /* ignore */ }
}

interface NotificationState {
  notifications: Notification[];
  /** Добавить уведомление */
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt'>) => void;
  /** Отметить как прочитанное */
  markAsRead: (id: string) => void;
  /** Отметить все как прочитанные */
  markAllAsRead: () => void;
  /** Удалить уведомление */
  removeNotification: (id: string) => void;
  /** Очистить все уведомления */
  clearAll: () => void;
  /** Получить непрочитанные */
  getUnreadCount: () => number;
  /** Получить уведомления пользователя */
  getUserNotifications: (userId: string) => Notification[];
}

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: loadNotifications(),

  addNotification: (notification) => {
    const newNotification: Notification = {
      ...notification,
      id: generateId(),
      createdAt: new Date().toISOString(),
    };
    set((state) => {
      const updated = [newNotification, ...state.notifications];
      saveNotifications(updated);
      return { notifications: updated };
    });
  },

  markAsRead: (id) => {
    set((state) => {
      const updated = state.notifications.map((n) =>
        n.id === id ? { ...n, read: true } : n
      );
      saveNotifications(updated);
      return { notifications: updated };
    });
  },

  markAllAsRead: () => {
    set((state) => {
      const updated = state.notifications.map((n) => ({ ...n, read: true }));
      saveNotifications(updated);
      return { notifications: updated };
    });
  },

  removeNotification: (id) => {
    set((state) => {
      const updated = state.notifications.filter((n) => n.id !== id);
      saveNotifications(updated);
      return { notifications: updated };
    });
  },

  clearAll: () => {
    saveNotifications([]);
    set({ notifications: [] });
  },

  getUnreadCount: () => {
    return get().notifications.filter((n) => !n.read).length;
  },

  getUserNotifications: (userId) => {
    return get().notifications
      .filter((n) => n.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },
}));
