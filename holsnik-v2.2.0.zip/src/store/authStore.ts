import { create } from 'zustand';
import type { UserProfile, AuthMethod } from '../types';
import { generateId } from '../types';

const AUTH_STORAGE_KEY = 'holsnik_auth';

function loadAuth(): Partial<AuthState> | null {
  try {
    const saved = localStorage.getItem(AUTH_STORAGE_KEY);
    return saved ? JSON.parse(saved) : null;
  } catch {
    return null;
  }
}

function saveAuth(state: AuthState): void {
  try {
    localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify({
      isAuthenticated: state.isAuthenticated,
      method: state.method,
      user: state.user,
    }));
  } catch { /* ignore */ }
}

interface AuthState {
  isAuthenticated: boolean;
  isLoading: boolean;
  method: AuthMethod | null;
  user: UserProfile | null;
  phoneInput: string;
  smsCode: string;
  smsSent: boolean;

  loginWithTelegram: (tgUser?: { id: number; first_name: string; last_name?: string; username?: string; photo_url?: string } | null) => void;
  sendSms: (phone: string) => void;
  verifySms: (code: string) => boolean;
  logout: () => void;
  setPhoneInput: (v: string) => void;
  setSmsCode: (v: string) => void;
  /** Обновить профиль пользователя */
  updateProfile: (updates: Partial<Omit<UserProfile, 'id' | 'telegramId' | 'createdAt'>>) => void;
  /** Проверить является ли пользователь админом */
  checkIsAdmin: () => boolean;
}

const savedAuth = loadAuth();

export const useAuthStore = create<AuthState>((set, get) => ({
  isAuthenticated: savedAuth?.isAuthenticated ?? false,
  isLoading: false,
  method: savedAuth?.method ?? null,
  user: savedAuth?.user ?? null,
  phoneInput: '+375 ',
  smsCode: '',
  smsSent: false,

  loginWithTelegram: (tgUser) => {
    set({ isLoading: true });
    setTimeout(() => {
      const isAdmin = tgUser?.id === 6250745595; // Admin ID from config
      const profile: UserProfile = {
        id: tgUser ? `tg_${tgUser.id}` : generateId(),
        telegramId: tgUser?.id,
        firstName: tgUser?.first_name || 'Пользователь',
        lastName: tgUser?.last_name,
        username: tgUser?.username,
        avatarUrl: tgUser?.photo_url,
        language: 'ru',
        createdAt: new Date().toISOString(),
        isAdmin,
      };
      const newState = {
        isAuthenticated: true,
        isLoading: false,
        method: 'telegram' as const,
        user: profile,
      };
      set(newState);
      saveAuth({ ...get(), ...newState });
    }, 400);
  },

  sendSms: () => {
    set({ isLoading: true });
    setTimeout(() => {
      set({ smsSent: true, isLoading: false });
    }, 800);
  },

  verifySms: (code: string) => {
    if (code === '1234') {
      const newState = {
        isAuthenticated: true,
        isLoading: false,
        method: 'phone' as const,
        user: {
          id: generateId(),
          firstName: 'Пользователь',
          phone: '+375 29 000-00-00',
          language: 'ru' as const,
          createdAt: new Date().toISOString(),
          isAdmin: false,
        } as UserProfile,
      };
      set(newState);
      saveAuth({ ...get(), ...newState });
      return true;
    }
    return false;
  },

  logout: () => {
    localStorage.removeItem(AUTH_STORAGE_KEY);
    set({
      isAuthenticated: false,
      method: null,
      user: null,
      phoneInput: '+375 ',
      smsCode: '',
      smsSent: false,
    });
  },

  setPhoneInput: (v) => set({ phoneInput: v }),
  setSmsCode: (v) => set({ smsCode: v }),

  updateProfile: (updates) => {
    set((state) => {
      if (!state.user) return state;
      const updatedUser = { ...state.user, ...updates };
      const newState = { ...state, user: updatedUser };
      saveAuth(newState);
      return newState;
    });
  },

  checkIsAdmin: () => {
    const user = get().user;
    return user?.isAdmin === true;
  },
}));
