import { create } from 'zustand';
import type { Order, OrderItem, OrderStatus, TrackingEntry, DeliveryMethod, DeliveryRates } from '../types';
import { generateId, STATUS_MAP } from '../types';
import { notifyNewOrder, notifyReturnRequest } from '../lib/telegram';

const STORAGE_KEY = 'holsnik_orders';

function loadOrders(): Order[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : [];
  } catch {
    return [];
  }
}

function saveOrders(orders: Order[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(orders));
  } catch { /* ignore */ }
}

interface OrderState {
  orders: Order[];
  rates: DeliveryRates;

  createOrder: (items: OrderItem[], method: DeliveryMethod, userName: string, username?: string, telegramChatId?: number) => Order;
  requestReturn: (orderId: string, itemId: string, reason: string, comment: string, userName: string, username?: string) => void;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  getOrderById: (id: string) => Order | undefined;
  clearAllOrders: () => void;
}

export const useOrderStore = create<OrderState>((set, get) => ({
  orders: loadOrders(),
  rates: {
    airPerKg: 49,
    autoPerKg: 22.9,
    commissionRate: 0,
    cnyToByn: 0.53,
  },

  createOrder: (items, method, userName, username, telegramChatId) => {
    const { rates } = get();
    const totalWeightKg = items.reduce((s, i) => s + i.weightKg * i.quantity, 0);
    const totalPriceCny = items.reduce((s, i) => s + i.priceCny * i.quantity, 0);
    const ratePerKg = method === 'air' ? rates.airPerKg : rates.autoPerKg;
    const deliveryPriceByn = Math.round(totalWeightKg * ratePerKg * 100) / 100;
    const productCostByn = Math.round(totalPriceCny * rates.cnyToByn * 100) / 100;

    const now = new Date().toISOString();
    const newOrder: Order = {
      id: `ORD-${generateId().slice(0, 6).toUpperCase()}`,
      userId: 'user',
      status: 'pending',
      deliveryMethod: method,
      totalPriceCny,
      totalPriceByn: Math.round((productCostByn + deliveryPriceByn) * 100) / 100,
      deliveryPriceByn,
      commissionByn: 0,
      totalWeightKg,
      createdAt: now,
      updatedAt: now,
      items: items.map(item => ({ ...item, orderId: '', status: 'pending' as const })),
      history: [{ id: generateId(), orderId: '', status: 'pending', description: 'Заказ создан, ожидает выкупа', timestamp: now }],
      telegramChatId,
      customerName: userName,
      customerUsername: username,
    };
    newOrder.items = newOrder.items.map(i => ({ ...i, orderId: newOrder.id }));
    newOrder.history = newOrder.history.map(h => ({ ...h, orderId: newOrder.id }));

    set((state) => {
      const updated = [newOrder, ...state.orders];
      saveOrders(updated);
      return { orders: updated };
    });

    // Уведомление менеджеру
    notifyNewOrder({
      orderId: newOrder.id,
      userName,
      username,
      items: items.map(i => ({ name: i.name, priceCny: i.priceCny, quantity: i.quantity, weightKg: i.weightKg })),
      deliveryMethod: method === 'air' ? 'Авиа ✈️' : 'Авто 🚚',
      totalByn: newOrder.totalPriceByn,
      totalCny: totalPriceCny,
    });

    return newOrder;
  },

  requestReturn: (orderId, itemId, reason, comment, userName, username) => {
    set((state) => {
      const updated = state.orders.map(o => {
        if (o.id !== orderId) return o;
        const entry: TrackingEntry = {
          id: generateId(),
          orderId,
          status: 'problem',
          description: `Запрос на возврат: ${reason}`,
          timestamp: new Date().toISOString(),
        };
        return {
          ...o,
          status: 'problem' as const,
          updatedAt: new Date().toISOString(),
          history: [...o.history, entry],
          items: o.items.map(i =>
            i.id === itemId
              ? { ...i, status: 'problem' as const, returnRequested: true, returnReason: reason, returnComment: comment }
              : i
          ),
        };
      });
      saveOrders(updated);

      const order = updated.find(o => o.id === orderId);
      const item = order?.items.find(i => i.id === itemId);
      if (item) {
        notifyReturnRequest({
          orderId,
          itemId,
          itemName: item.name,
          reason,
          userName,
          username,
          comment,
        });
      }

      return { orders: updated };
    });
  },

  updateOrderStatus: (orderId, status) => {
    set((state) => {
      const updated = state.orders.map(o => {
        if (o.id !== orderId) return o;
        const entry: TrackingEntry = {
          id: generateId(),
          orderId,
          status,
          description: STATUS_MAP[status].label,
          timestamp: new Date().toISOString(),
        };
        return {
          ...o,
          status,
          updatedAt: new Date().toISOString(),
          history: [...o.history, entry],
          ...(status === 'delivered' ? { deliveredAt: new Date().toISOString() } : {}),
        };
      });
      saveOrders(updated);
      return { orders: updated };
    });
  },

  getOrderById: (id) => get().orders.find(o => o.id === id),
  clearAllOrders: () => { set({ orders: [] }); saveOrders([]); },
}));
